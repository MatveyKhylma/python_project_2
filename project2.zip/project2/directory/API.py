# import requests
# import jsonify
# import json
# # Отправляем GET-запрос к API случайного пользователя
# r = requests.get('https://randomuser.me/api/')
# # Получаем ответ в формате JSON
# data = r.json()
# # Выводим результат
# print(data)
#
# api_key = 'Eqenp6euvkSxWLaIWTB7LbVkGmHAqae8'
# location_url = "http://dataservice.accuweather.com/locations/v1/cities/geoposition/search"
# current_conditions = "http://dataservice.accuweather.com/currentconditions/v1/"
# # получим ключ
# def get_location_key(lat, lon):
#     params = {
#         'apikey': api_key,
#         'q': f"{lat},{lon}"
#     }
#     response = requests.get(location_url, params=params)
#     if response.status_code == 200:
#         data = response.json()
#         return data.get('Key')
#     else:
#         print("Ошибка получения Location Key:", response.status_code, response.text)
#         return None
#
# # получим погоду по ключу
# def get_weather(location_key):
#     params = {
#         'apikey': api_key
#     }
#     response = requests.get(f"{current_conditions}{location_key}", params=params)
#     if response.status_code == 200:
#         return response.json()
#     else:
#         print("Ошибка получения погоды:", response.status_code, response.text)
#         return None
#
# def extract_weather_data(weather_data):
#     if not weather_data or not isinstance(weather_data, list) or len(weather_data) == 0:
#         return None
#     weather_summary = {
#         'tempreture': data['Temperature']['Metric']['Value'],
#         'humidity': data['RelativeHumidity'],
#         'speed_wind': data['Wind']['Speed']['Metric']['Value'],
#         'probability_rain': data.get('PrecipitationProbability', 0)
#     }
#     return weather_summary
#
# # # @app.route('/weather/<lat>/<lon>')
# # def weather(lat, lon):
# #     """Эндпоинт для получения погоды по координатам"""
# #     location_key = get_location_key(lat, lon)
# #     if not location_key:
# #         return jsonify({"error": "Не удалось получить Location Key"}), 500
# #     weather_data = get_weather(location_key)
# #     if not weather_data:
# #         return jsonify({"error": "Не удалось получить данные о погоде"}), 500
# #     return jsonify(weather_data)
#
# def save_to_json(data, filename):
#     """Сохранение данных в JSON"""
#     with open(filename, 'w') as f:
#         json.dump(data, f, indent=4)
#     print(f"Данные успешно сохранены в {filename}")
#
# @app.route('/weather', methods=['GET'])
#
# if __name__ == '__main__':
#     app.run(debug=True)
# # Cоздаём класс
# # class AccuWeatherInfo:
#   # Ссылка на API погоды. location key заменить
#   # api_url = 'http://dataservice.accuweather.com/forecasts/v1/daily/1day/{locationKey}'
#   # api_url = 'http://dataservice.accuweather.com/locations/v1/cities/geoposition/search'
#
#
#
