from flask import Flask, render_template, request, jsonify
import requests

app = Flask(__name__)

# Конфигурация API
API_KEY = 'Eqenp6euvkSxWLaIWTB7LbVkGmHAqae8'
LOCATION_URL = "http://dataservice.accuweather.com/locations/v1/cities/geoposition/search"
CURRENT_CONDITIONS_URL = "http://dataservice.accuweather.com/currentconditions/v1/"


def get_location_key(lat, lon):

    params = {
        'apikey': API_KEY,
        'q': f"{lat},{lon}"
    }
    response = requests.get(LOCATION_URL, params=params)
    if response.status_code == 200:
        try:
            data = response.json()
            return data.get('Key')
        except (KeyError, ValueError):
            return None
    return None


def get_weather(location_key):

    params = {'apikey': API_KEY}
    response = requests.get(f"{CURRENT_CONDITIONS_URL}{location_key}", params=params)
    if response.status_code == 200:
        try:
            return response.json()
        except (KeyError, ValueError):
            return None
    return None


def extract_weather_data(weather_data):

    if not weather_data or not isinstance(weather_data, list) or len(weather_data) == 0:
        return None

    data = weather_data[0]
    return {
        'temperature': data.get('Temperature', {}).get('Metric', {}).get('Value', "Нет данных"),
        'humidity': data.get('RelativeHumidity', "Нет данных"),
        'wind_speed': data.get('Wind', {}).get('Speed', {}).get('Metric', {}).get('Value', "Нет данных"),
        'rain_probability': data.get('PrecipitationProbability', "Нет данных"),
        'weather_text': data.get('WeatherText', "Нет данных")
    }


def check_bad_weather(weather_summary):

    if not weather_summary:
        return False

    temperature = weather_summary.get('temperature', 0)
    rain_probability = weather_summary.get('rain_probability', 0)
    wind_speed = weather_summary.get('wind_speed', 0)

    return (
        temperature < 0 or
        temperature > 35 or
        rain_probability > 70 or
        wind_speed > 50
    )


@app.route('/')
def home():

    return render_template('index.html')


@app.route('/check_weather', methods=['POST'])
def check_weather():

    try:
        start_lat = float(request.form.get('start_lat'))
        start_lon = float(request.form.get('start_lon'))
        end_lat = float(request.form.get('end_lat'))
        end_lon = float(request.form.get('end_lon'))
    except (ValueError, TypeError):
        return render_template('result.html', result="Ошибка: координаты должны быть числами.")


    start_key = get_location_key(start_lat, start_lon)
    end_key = get_location_key(end_lat, end_lon)

    if not start_key or not end_key:
        return render_template('result.html', result="Не удалось получить Location Key для одной из точек маршрута.")

    start_weather = get_weather(start_key)
    end_weather = get_weather(end_key)

    if not start_weather or not end_weather:
        return render_template('result.html', result="Не удалось получить погодные данные.")

    start_summary = extract_weather_data(start_weather)
    end_summary = extract_weather_data(end_weather)

    if not start_summary or not end_summary:
        return render_template('result.html', result="Не удалось извлечь данные о погоде.")


    start_bad_weather = check_bad_weather(start_summary)
    end_bad_weather = check_bad_weather(end_summary)

    result = {
        "start_weather": start_summary,
        "end_weather": end_summary,
        "start_bad_weather": start_bad_weather,
        "end_bad_weather": end_bad_weather
    }

    return render_template('result.html', result=result)


if __name__ == '__main__':
    app.run(debug=True, port=5001)
